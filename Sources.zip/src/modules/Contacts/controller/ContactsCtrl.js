/**
 * @module Controller for page home of public section layout.
 * @class ContactsController
 */
export default class ContactsController {
  /**
   * @constructor
   */
  constructor() {
    "ngInject";
  }
}
