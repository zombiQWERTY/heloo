/**
 * @module Controller for page home of public section layout.
 * @class BusinessController
 */
export default class BusinessController {
  /**
   * @constructor
   */
  constructor() {
    "ngInject";
  }
}
