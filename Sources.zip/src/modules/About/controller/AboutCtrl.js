/**
 * @module Controller for page home of public section layout.
 * @class AboutController
 */
export default class AboutController {
  /**
   * @constructor
   */
  constructor() {
    "ngInject";
  }
}
