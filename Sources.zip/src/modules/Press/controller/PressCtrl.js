/**
 * @module Controller for page home of public section layout.
 * @class PressController
 */
export default class PressController {
  /**
   * @constructor
   */
  constructor() {
    "ngInject";
  }
}
